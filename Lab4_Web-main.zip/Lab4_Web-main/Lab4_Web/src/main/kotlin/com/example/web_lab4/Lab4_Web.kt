package com.example.web_lab4

import org.springframework.boot.autoconfigure.SpringBootApplication
import org.springframework.boot.runApplication

@SpringBootApplication
class WebLab4Application

fun main(args: Array<String>) {
    runApplication<WebLab4Application>(*args)
}
