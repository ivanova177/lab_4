package com.example.web_lab4.model

data class Bank(
        val accountNumber: String,
        val trust: Double,
        val transactionFee: Int
)
